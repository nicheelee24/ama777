import YESBINGO from '../assets/img/Bingo/Yesbingo_v1.png'

export const Bingo = [
  {
    imageUrl: YESBINGO,
    platform: "YESBINGO"
  }
]