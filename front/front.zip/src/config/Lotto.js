import VRLOTTO from '../assets/img/Lotto/VRLOTTO.png'

export const Lotto = [
  {
    imageUrl: VRLOTTO,
    platform: "VRLOTTO"
  }
]