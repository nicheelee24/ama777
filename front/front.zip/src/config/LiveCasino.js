import BG from "../assets/img/LiveCasino/BG-1.png";
import EVOLUTION from "../assets/img/LiveCasino/EVOLUTION-1.png";
import HORSEBOOK from "../assets/img/LiveCasino/HORSEBOOK-1.png";
import PP from "../assets/img/LiveCasino/PP-1.png";
import PT from "../assets/img/LiveCasino/PT-1.png";
import SEXYBCRT from "../assets/img/LiveCasino/SEXYBCRT.png";
// import SEXYBCRT from "../assets/img/LiveCasino/SV388-1.png";
import SV388 from "../assets/img/LiveCasino/SV388-1.png";
import VENUS from "../assets/img/LiveCasino/VENUS-1.png";

export const LiveCasino = [
    // {
    //     imageUrl: BG,
    //     platform: "BG",
    // },
    {
        imageUrl: EVOLUTION,
        platform: "EVOLUTION",
    },
    {
        imageUrl: HORSEBOOK,
        platform: "HORSEBOOK",
    },
    {
        imageUrl: PP,
        platform: "PP",
    },
    {
        imageUrl: PT,
        platform: "PT",
    },
    {
        imageUrl: SEXYBCRT,
        platform: "SEXYBCRT",
    },
    {
        imageUrl: SV388,
        platform: "SV388",
    },
    {
        imageUrl: VENUS,
        platform: "VENUS",
    },
];
