import SABA from '../assets/img/Virtual/SABA.png'

export const Chicken = [
  {
    // imageUrl: SABA,
    // platform: "SABA"
  }
]