import SABA from '../assets/img/Virtual/SABA.png'

export const Thai = [
  {
      imageUrl: SABA,
      platform: "ALL"
  }
]