import SABA from '../assets/img/Virtual/SABA.png'

export const Virtual = [
  {
    imageUrl: SABA,
    platform: "SABA"
  }
]